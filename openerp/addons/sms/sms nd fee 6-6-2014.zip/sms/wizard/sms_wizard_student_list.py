from openerp.osv import fields, osv
import datetime

class sms_student_list(osv.osv_memory):

    _name = "sms.studentlist"
    _description = "will print student list"
    _columns = {
              'acad_cal':fields.many2one('sms.academiccalendar','Academic Calendar',domain = [('state','=','Active')] ),
              'list_type': fields.selection([('contact_list','Contact list'),('check_admissions','Check Admissions')], 'List Type', required = True),
              'start_date': fields.date('Start Date'),
              'end_date':fields.date('End Ddate'),
             }
    _defaults = {
           }

    def print_list(self, cr, uid, ids, data):
        result = []
        
        student_ids = self.pool.get('sms.student').search(cr,uid,[('state','!=','Draft')])
        student_rows =  self.pool.get('sms.student').browse(cr,uid,student_ids)
#         for student_row in student_rows:
#             self.pool.get('sms.student').write(cr, uid, student_row.id,{'state':student_row.state})
            
        thisform = self.read(cr, uid, ids)[0]
        listtype = thisform['list_type']
        
        if listtype =='contact_list':
            report = 'sms.studentslist.name'
        elif listtype =='check_admissions':
            report = 'sms.std_admission_statistics.name'
            raise osv.except_osv(('Availabl Soon'),('This report is temporarily unavailable'))
 
        datas = {
             'ids': [],
             'active_ids': '',
             'model': 'sms.studentlist',
             'form': self.read(cr, uid, ids)[0],
        }
        return {
            'type': 'ir.actions.report.xml',
            'report_name':report,
            'datas': datas,
        }
    
    
    
sms_student_list()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: