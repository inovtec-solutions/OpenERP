from openerp.osv import fields, osv
import datetime

class change_student_class(osv.osv_memory):

    def _get_active_session(self, cr, uid, context={}):
        ssn = self.pool.get('sms.session').search(cr, uid, [('state','=','Active')])
        return ssn[0]
    
    _name = "change.student.class"
    _description = "Student Change Section"
    _columns = {
                'session': fields.many2one('sms.session', 'Session', domain="[('state','!=','Previous')]", required=True, help="Select A Session of the Classes"),
                'action':fields.selection([('change_class','Change Class (Making Class Correction)'),('change_section','Change Section (An Academic Process)')],'Action',required = True),
                'display_text':fields.text('Text', readonly=True),
                'apply_fees':fields.selection([('at_admission','Apply Fee applicable at the time of admission'),('at_promotion','Apply Fee applicable at the time of promotion')],'Apply Fee'),
                'academiccalendar_id': fields.many2one('sms.academiccalendar','From Class', domain="[('session_id','=',session)]", required=True),
                'academiccalendar_to': fields.many2one('sms.academiccalendar','To Class', domain="[('session_id','=',session),('id','!=',academiccalendar_id)]", required=True),
                'fee_starting_month': fields.many2one('sms.session.months', 'Starting Fee Month', domain="[('session_id','=',session)]", required=True, help="Select A starting month for fee of this student "),
                
              }
    _defaults = {'session':_get_active_session,
                 'display_text':'1. Change Student Class:\n Use this option to change stuent class if student was admiteed or promoted to wrong class. All subjects and fee details will be deleted.\n\n2. Change Student Section:\n Use this option if you want to change student section as part of academic p[eration. His previous class record will be maintained.'}
    
    def onchange_action(self, cr, uid, ids,ids2):
        result = {}
        res = {}
        print "ids:",ids
        print "ids2:",ids2
        for f in self.browse(cr, uid, ids):
            print "wizardobj:",f
            current_obj = self.pool.get('sms.academiccalendar').browse(cr, uid, f.academiccalendar_id.id, context=context)
            if f.action == 'change_section':
                class_id = current_obj.class_id.id
                print class_id
                class_state = current_obj.state
                print class_state
                f.display_text= 'Change Student Section'
                academiccalendar_ids = self.pool.get('sms.academiccalendar').search(cr,uid,[('id','!=',current_obj.id),('class_id','=',class_id),('state','=',class_state)])
            else:
                req_state = current_obj.state 
                academiccalendar_ids = self.pool.get('sms.academiccalendar').search(cr,uid,[('id','!=',current_obj.id),('state','=',req_state)])
                f.display_text= 'Student Class subjects & Fee Will be deleted. New Subjects will be assigned.'
            res = {'domain': {'academiccalendar_to_id': [('id', 'in', academiccalendar_ids)]},value:f.display_text}
        return res 
    
    
        
    def change_student_class(self, cr, uid, ids, context=None):
        current_obj = self.browse(cr, uid, ids, context=context)
        
        cr.execute("""select id,name from ir_ui_view 
                    where model= 'sms.change.student.class' 
                    and type='tree'""")
        view_res = cr.fetchone()
            
        sql="""delete from sms_change_student_class"""
        cr.execute(sql)
        cr.commit()

        sql = """SELECT sms_student.id, sms_student.registration_no, sms_student.name, sms_student.father_name, sms_academiccalendar_student.id,
                sms_student.fee_type
            from sms_student 
            inner join sms_academiccalendar_student
            on sms_student.id = sms_academiccalendar_student.std_id
            where sms_academiccalendar_student.name = """ + str(current_obj[0].academiccalendar_id.id) + """
            and sms_academiccalendar_student.state = 'Current'
            and sms_student.state = 'Admitted'
            ORDER BY name, father_name"""
        
        cr.execute(sql)
        student_rows = cr.fetchall()
        i = 1
        for student_row in student_rows:    
            sms_temp_detail_new_id = self.pool.get('sms.change.student.class').create(cr,uid,
            {
                'name':student_row[0],
                'registration_no':student_row[1],
                'father_name':student_row[3],
                'session_id':current_obj[0].session.id,
                'apply_fees':current_obj[0].apply_fees,
                'sms_academiccalendar_student':student_row[4],
                'sms_academiccalendar_from':current_obj[0].academiccalendar_id.id,
                'sms_academiccalendar_to':current_obj[0].academiccalendar_to.id,
                'fee_str':student_row[5],
                'fee_starting_month':current_obj[0].fee_starting_month.id,
                'action':current_obj[0].action,
                'sno':i,
                'change_class':False,})
            i = i +1
                 
        return {
            #'domain': "[('parent_default_exam','=',"+str(sms_temp_new_id)+")]",
            'name': 'Change Student Class: ' +  str(current_obj[0].academiccalendar_id.name),
            'view_type': 'form',
            'view_mode': 'tree',
            'res_model': 'sms.change.student.class',
            'view_id': view_res,
            'type': 'ir.actions.act_window'}
        
change_student_class()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: