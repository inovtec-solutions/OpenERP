from openerp.osv import fields, osv

class sms_student_subject_assignment(osv.osv_memory):

    _name = "sms.student.subject.assignment"
    _description = "Subject Assignment"
    _columns = {
                'academiccalendar_id': fields.many2one('sms.academiccalendar','Select Class', domain="[('state','=','Active')]", required=True,),
                'subject_id': fields.many2one('sms.subject','Select Subject', required=True),
                'teacher_id': fields.many2one('hr.employee','Teacher', required=True),
                'is_practical': fields.boolean('Is Practical'),
                'academiccalendar_subject_id': fields.many2one('sms.academiccalendar.subjects','Practical of', domain="[('academic_calendar','=',academiccalendar_id)]"),
            }
    _defaults = {
            'is_practical': False,
           }
    
    def onchange_academiccalendar(self, cr, uid, ids, context=None):
        result = {}
        result['academiccalendar_subject_id'] = None
        return {'value': result}

    def assign_subject(self, cr, uid, ids, context=None):
        current_obj = self.browse(cr, uid, ids, context=context)       
        
        for obj in current_obj:
            if obj.is_practical:
                subject_id = self.pool.get('sms.academiccalendar.subjects').create(cr,uid,{
                    'subject_id':obj.subject_id.id,                                                       
                    'academic_calendar':obj.academiccalendar_id.id,
                    'total_marks':100,
                    'passing_marks':40, 
                    'state':'Current',
                    'teacher_id':obj.teacher_id.id,
                    'is_practical':True,
                    'reference_practical_of':obj.academiccalendar_subject_id.id,})
                
                self.pool.get('sms.academiccalendar.subjects').write(cr, uid, obj.academiccalendar_subject_id.id, {'has_practical':True,})

            else:
                subject_id = self.pool.get('sms.academiccalendar.subjects').create(cr,uid,{
                    'subject_id':obj.subject_id.id,                                                       
                    'academic_calendar':obj.academiccalendar_id.id,
                    'total_marks':100,
                    'passing_marks':40, 
                    'state':'Current',
                    'teacher_id':obj.teacher_id.id,})
            
            student_ids = self.pool.get('sms.academiccalendar.student').search(cr,uid,[('name','=',obj.academiccalendar_id.id)])
            student_objs = self.pool.get('sms.academiccalendar.student').browse(cr, uid, student_ids, context=context)
            
            for student_obj in student_objs:
                
                reference_practical_of = None
                if obj.is_practical:
                    reference_practical_of = self.pool.get('sms.student.subject').search(cr,uid,[('student','=',student_obj.id),('subject','=',obj.academiccalendar_subject_id.id)])[0]

                self.pool.get('sms.student.subject').create(cr,uid,{
                    'student':student_obj.id,                                                       
                    'subject':subject_id,
                    'student_id':student_obj.std_id.id,
                    'reference_practical_of':reference_practical_of,})
        
        return {}
        
sms_student_subject_assignment()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: