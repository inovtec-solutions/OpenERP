from openerp.osv import fields, osv
import datetime

class exam_datesheet(osv.osv_memory):

    _name = "exam.datesheet"
    _description = "Exam Date Sheet"
    _columns = {
                 'exam_type': fields.many2one('sms.exam.type', 'Exam Type',required=True),
                 'academiccalendar':fields.many2one('sms.academiccalendar', 'Class',required=True),
                 'subject_marks':fields.integer('Subects Marks',required=True),
                 'start_date': fields.date('start_date',required =True),
              }
    
    _defaults = {
            'subject_marks': 100,
           }
    
    
    def exam_datesheet(self, cr, uid, ids, context=None):
        current_obj = self.browse(cr, uid, ids, context=context)
        cr.execute("""select id,name from ir_ui_view 
                    where model= 'sms.exam.datesheet.lines' 
                    and type='tree'""")
        view_res = cr.fetchone()
            
        start_date = current_obj[0].start_date.split('-')
        
        year = int(start_date[0])
        month = int(start_date[1])

        first_date = datetime.date(year, month, 1)
        if month == 12:
            last_date = datetime.date(year + 1, month, 1) - datetime.timedelta(1,0,0)
        else:
            last_date = datetime.date(year, month + 1, 1) - datetime.timedelta(1,0,0)
            
        is_exist_sql = """SELECT sms_exam_datesheet.id FROM sms_exam_datesheet
             WHERE sms_exam_datesheet.academiccalendar = """ + str(current_obj[0].academiccalendar.id) + """
             AND sms_exam_datesheet.exam_type = """ + str(current_obj[0].exam_type.id) + """
             AND sms_exam_datesheet.start_date between '""" + str(first_date) + """' AND '""" + str(last_date) + """'"""
             
        cr.execute(is_exist_sql)
        is_exit_row = cr.fetchone()
        
        if is_exit_row:
            datesheet_id = is_exit_row[0]
        
        else:
            sql = """SELECT sms_academiccalendar_subjects.id FROM sms_academiccalendar_subjects
                     WHERE sms_academiccalendar_subjects.academic_calendar ="""+str(current_obj[0].academiccalendar.id)+"""
                     AND sms_academiccalendar_subjects.state = 'Current'"""
            
            cr.execute(sql)
            rec = cr.fetchall()
            
            datesheet_obj = self.pool.get('sms.exam.datesheet')
            datesheelines_obj = self.pool.get('sms.exam.datesheet.lines')
            
            datesheet_id = datesheet_obj.create(cr,uid,{'academiccalendar':current_obj[0].academiccalendar.id, 'exam_type':current_obj[0].exam_type.id,'start_date':current_obj[0].start_date,'status':'Active'})
            for each in rec:
                
                d_sheetlines_id = datesheelines_obj.create(cr,uid,
                {
                'name':datesheet_id,
                'subject':each[0],
                'total_marks':current_obj[0].subject_marks,
                'paper_date':datetime.date.today(),
                'invigilator':1,
                })
                
                
        return {
            'domain': "[('name','=',"+str(datesheet_id)+")]",
            'name': 'Exam Date Sheet:' +  str(current_obj[0].exam_type.name),
            'view_type': 'form',
            'view_mode': 'tree',
            'res_model': 'sms.exam.datesheet.lines',
            'view_id': view_res,
            'type': 'ir.actions.act_window'}
        
exam_datesheet()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: