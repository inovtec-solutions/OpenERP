# -*- coding: utf-8 -*-
##############################################################################
#    
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Tiny SPRL (<http://tiny.be>).
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.     
#
##############################################################################
import sms_wizard_admit_student
import sms_wizard_swap_move_timetable_entry
import sms_wizard_timetable_entry
import sms_wizard_admission_form
import sms_wizard_admit_student
import sms_wizard_student_list
import sms_wizard_exam_entry
import sms_wizard_exam_students_lists
import sms_wizard_exam_students_dmc
import sms_wizard_exam_datesheet
import sms_wizard_students_subject_assignment
import sms_wizard_students_subject_removal
import sms_wizard_withdraw_student
import sms_wizard_load_students
import sms_wizard_student_promote
import sms_wizard_failed_student_class_assignment
import sms_wizard_student_change_section
import sms_wizard_change_student_class
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

