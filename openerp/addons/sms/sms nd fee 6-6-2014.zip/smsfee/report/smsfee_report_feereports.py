import time
from openerp.report import report_sxw
import datetime

class smsfee_report_feereports(report_sxw.rml_parse):
    def __init__(self, cr, uid, name, context):
        super(smsfee_report_feereports, self).__init__(cr, uid, name, context = context)
        self.localcontext.update( {
            'time': time,
            'report_title': self.report_title,
            'get_class_name': self.get_class_name,
            'annual_report_allclasses': self.annual_report_allclasses,
            'annual_report_singleclass': self.annual_report_singleclass,
            'monthly_feecollection_allclasses': self.monthly_feecollection_allclasses,
            'get_month_name':self.get_month_name,
            'students_paidfee_report':self.students_paidfee_report,
            'monthwise_defaulter_studentslist':self.monthwise_defaulter_studentslist,
            'student_fee_receipts':self.student_fee_receipts,
            'daily_fee_report':self.daily_fee_report,
            'company_name':self.company_name,
            'get_user_name':self.get_user_name,
            'get_today':self.get_today,
            'data_ranges':self.data_ranges,
        })
        self.base_amount = 0.00
    
    def report_title(self, data):  
        start_date = self.pool.get('sms.session').set_date_format(self.cr, self.uid,self.datas['form']['from_date'])
        end_date = self.pool.get('sms.session').set_date_format(self.cr, self.uid,self.datas['form']['to_date'])
        string = "Students Admissions \n " +str(start_date) + "-TO -"+str(end_date)
        return string
    
    def get_today(self, data):
        today = datetime.date.today()
#         dated = self.pool.get('sms.session').set_date_format(self.cr,self.uid,today)
        return today
    
    def get_user_name(self, data):
        return self.pool.get('res.users').browse(self.cr, self.uid,self.uid).name
    
    def get_class_name(self, data):  
        return self.pool.get('sms.academiccalendar').browse(self.cr, self.uid,self.datas['form']['class_id'][0]).name
    
    def data_ranges(self, data):  
        from_date = self.pool.get('sms.session').set_date_format(self.cr, self.uid,self.datas['form']['from_date'])
        to_date = self.pool.get('sms.session').set_date_format(self.cr, self.uid,self.datas['form']['to_date'])
        range = "From: "+str(from_date)+" To "+str(to_date)
        return range
    
    def company_name(self, data):  
        return self.pool.get('smsfee.classes.fees').get_company(self.cr, self.uid,self.uid)
    
    def get_month_name(self, data):  
        return self.pool.get('sms.session.months').browse(self.cr, self.uid,self.datas['form']['month'][0]).name
    
    def annual_report_allclasses(self, data):                                                         
        result = []
        this_form = self.datas['form']
#         acad_cal = this_form['acad_cal'][0]
        session_id = this_form['session'][0]
        reporttype = this_form['report_type']
#         students = self.pool.get('sms.academiccalendar.student').search(self.cr, self.uid,[('name', '=', acad_cal),('state', '=','Current')])
#       
        session_months_ids = self.pool.get('sms.session.months').search(self.cr, self.uid,[('session_id', '=', session_id)])
        session_months_ids.sort()
        months = self.pool.get('sms.session.months').browse(self.cr, self.uid,session_months_ids)
        mydict = {'sno':'SNO','class':'Class','m1':'','m2':'','m3':'--','m4':'--','m5':'','m6':'','m7':'--','m8':'--','m9':'','m10':'','m11':'--','m12':'--','total':'--'}
        c = 1
        for mm in months:
            arr = mm.name.split('-')
            mydict['m'+str(c)] = arr[0][:3]+"\n"+arr[1]
            c = c + 1
        result.append(mydict) 
        session_cls_ids = self.pool.get('sms.academiccalendar').search(self.cr, self.uid,[('session_id', '=', session_id)]) 
        classes_list = self.pool.get('sms.academiccalendar').browse(self.cr, self.uid,session_cls_ids)
        i = 1
        grand_total = 0
        for cls in classes_list:
            mydict = {'sno':'SNO','class':'Class','m1':'','m2':'','m3':'--','m4':'--','m5':'','m6':'','m7':'--','m8':'--','m9':'','m10':'','m11':'--','m12':'--','total':'Total','gtotal':''}
            j = 1 
            clsname = cls.name
            mydict['class'] = clsname
            mtotal = 0
            for month in session_months_ids:
                                
                sql = """SELECT sum(paid_amount) FROM smsfee_studentfee WHERE reconcile = True
                         AND paid_amount>0
                         AND acad_cal_id = """+str(cls.id)+"""
                         AND (fee_month = """+str(month)+""" OR due_month = """+str(month)+""")""" 
                self.cr.execute(sql)
                amount = self.cr.fetchone()[0]
                if amount is None:
                    amount = "-"
                    mtotal = mtotal + 0
                else:
                    mtotal = mtotal + int(amount)     
                mydict['m'+str(j)] = amount
                mydict['total'] = mtotal
                j = j +1
            grand_total = grand_total + mtotal
            mydict['sno'] = i
            
            i = i +1    
            result.append(mydict)    
        mydict['gtotal'] = grand_total
        return result
    
    def annual_report_singleclass(self, data):                                                         
        result = []
        this_form = self.datas['form']
        cls_id = this_form['class_id'][0]

        reporttype = this_form['report_type']
        mydict = {'sno':'SNO','month':'Month','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','other':'Others','total':'TOTAL'}
        
        sql_fs = """ SELECT DISTINCT (smsfee_feetypes.id) FROM smsfee_feetypes
                    INNER JOIN smsfee_classes_fees
                    ON smsfee_feetypes.id = smsfee_classes_fees.fee_type_id
                    WHERE  smsfee_classes_fees.academic_cal_id = """+str(cls_id)
        
        self.cr.execute(sql_fs)
        ft_ids = self.cr.fetchall()
        c = 1
        for idss in ft_ids:
            ftname = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,idss[0]).name
            mydict['ft'+str(c)] = ftname
            c= c + 1
        result.append(mydict)
        
        brw_cls = self.pool.get('sms.academiccalendar').browse(self.cr, self.uid,cls_id)
        session_id = brw_cls.session_id.id
        session_months_ids = self.pool.get('sms.session.months').search(self.cr, self.uid,[('session_id', '=', session_id)])
        session_months_ids.sort()
        
        
        i = 1  
        grand_total = 0  
        for month in session_months_ids:
            mydict = {'sno':'SNO','month':'Month','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','other':'','total':'Total'}
            months = self.pool.get('sms.session.months').browse(self.cr, self.uid,month)
            mydict['month'] = months.name
            mydict['sno'] = i
            cal_month = months.session_month_id.id
            cal_year = months.session_year
            month_end =str(cal_year)+"/"+str(self.pool.get('sms.session.months').get_month_end_date(self.cr, self.uid,cal_month,cal_year))
            month_start = str(cal_year)+"/"+str(cal_month)+"/01"
            
            j = 1
            ft_total = 0
            for ft in ft_ids:
                subtype = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,ft[0]).subtype
                
                if subtype == 'Monthly_Fee':
                    print "this is monthly fee::,"
                    sql = """SELECT sum(smsfee_studentfee.paid_amount) FROM smsfee_studentfee
                             INNER JOIN smsfee_classes_fees
                             ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                             WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                             AND smsfee_studentfee.reconcile = True
                             AND acad_cal_id = """+str(cls_id)+"""
                             AND smsfee_studentfee.paid_amount>0
                             AND smsfee_studentfee.fee_month = """+str(month)
                            
                else:
                    sql = """SELECT sum(smsfee_studentfee.paid_amount) FROM smsfee_studentfee
                         INNER JOIN smsfee_classes_fees
                         ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                         WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                         AND smsfee_studentfee.reconcile = True
                         AND acad_cal_id = """+str(cls_id)+"""
                         AND smsfee_studentfee.paid_amount>0
                         AND smsfee_studentfee.due_month = """+str(month)
                                    
                self.cr.execute(sql)
                amount = self.cr.fetchone()[0]
                if amount is None:
                    amount = 0
                ft_total = int(ft_total) + int(amount)
                mydict['ft'+str(j)] = amount
                j = j + 1
            mydict['total'] = ft_total
            i = i + 1
            result.append(mydict)
        return result



    def monthly_feecollection_allclasses(self, data):                                                         
        result = []
        ####
        this_form = self.datas['form']
        session_id = this_form['session'][0]
        classes_ids = self.pool.get('sms.academiccalendar').search(self.cr, self.uid,[('session_id', '=', session_id)])
        classes_rec = self.pool.get('sms.academiccalendar').browse(self.cr, self.uid,classes_ids)
        
        ###
        mydict = {'sno':'SNO','class':'Class','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','other':'Others','total':'TOTAL'}
        
        sql_fs = """ SELECT  smsfee_feetypes.id FROM smsfee_feetypes"""
        self.cr.execute(sql_fs)
        ft_ids = self.cr.fetchall()
        
        c = 1
        
        for idss in ft_ids:
            ftname = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,idss[0]).name
            mydict['ft'+str(c)] = ftname
            c= c + 1
        result.append(mydict)
        ############################################################################################################################
        
        cal_month = self.pool.get('sms.session.months').browse(self.cr, self.uid,self.datas['form']['month'][0])
        cal_month_id = cal_month.session_month_id.id
        cal_year = cal_month.session_year
        month_end =str(cal_year)+"/"+str(self.pool.get('sms.session.months').get_month_end_date(self.cr, self.uid,cal_month_id,cal_year))
        print "month end:",month_end
        month_start = str(cal_year)+"/"+str(cal_month_id)+"/01"
        print "month state:",month_start
        
        i = 1    
        for cls in classes_rec:
            mydict = {'sno':'SNO','class':'Class','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','other':'','total':''}
            mydict['class'] = cls.name
            mydict['sno'] = i
            j = 1
            ft_total = 0
            for ft in ft_ids:
                subtype = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,ft[0]).subtype
                if subtype == 'Monthly_Fee':
                    print "this is monthly fee::,"
                    sql = """SELECT sum(smsfee_studentfee.paid_amount) FROM smsfee_studentfee
                             INNER JOIN smsfee_classes_fees
                             ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                             WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                             AND smsfee_studentfee.reconcile = True
                             AND acad_cal_id = """+str(cls.id)+"""
                             AND smsfee_studentfee.paid_amount>0
                             AND smsfee_studentfee.fee_month = """+str(self.datas['form']['month'][0])
                            
                else:
                    sql = """SELECT sum(smsfee_studentfee.paid_amount) FROM smsfee_studentfee
                         INNER JOIN smsfee_classes_fees
                         ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                         WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                         AND smsfee_studentfee.reconcile = True
                         AND acad_cal_id = """+str(cls.id)+"""
                         AND smsfee_studentfee.paid_amount>0
                         AND smsfee_studentfee.due_month = """+str(self.datas['form']['month'][0])

                self.cr.execute(sql)
                amount = self.cr.fetchone()[0]
                if amount is None:
                    amount = 0
                ft_total = int(ft_total) + int(amount)
                mydict['ft'+str(j)] = amount
                j = j + 1
            mydict['total'] = ft_total
            i = i + 1
            result.append(mydict)
        return result
#---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    def students_paidfee_report(self, data):                                                         
        result = []
        ####
        this_form = self.datas['form']
        cls_id = this_form['class_id'][0]
        print "class id:",cls_id
        std_ids = self.pool.get('sms.student').search(self.cr, self.uid,[('current_class', '=', cls_id)])
        students_rec = self.pool.get('sms.student').browse(self.cr, self.uid,std_ids)
        for test in students_rec:
            print "std name:", test.name
            print "std id:", test.id
        
        ###
        mydict = {'sno':'SNO','student':'Student','father':'Father','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','other':'','total':'TOTAL'}
        
        sql_fs = """ SELECT DISTINCT smsfee_feetypes.id,smsfee_feetypes.subtype  FROM smsfee_feetypes
                     INNER JOIN smsfee_classes_fees
                     ON smsfee_feetypes.id = smsfee_classes_fees.fee_type_id
                     WHERE  smsfee_classes_fees.academic_cal_id = """+str(cls_id)
        self.cr.execute(sql_fs)
        ft_ids = self.cr.fetchall()
        
        c = 1
        for idss in ft_ids:
            ftname = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,idss[0]).name
            mydict['ft'+str(c)] = ftname
            c= c + 1
        result.append(mydict)
        ############################################################################################################################
        
        cal_month = self.pool.get('sms.session.months').browse(self.cr, self.uid,self.datas['form']['month'][0])
        cal_month_id = cal_month.session_month_id.id
        cal_year = cal_month.session_year
        month_end =str(cal_year)+"/"+str(self.pool.get('sms.session.months').get_month_end_date(self.cr, self.uid,cal_month_id,cal_year))
        month_start = str(cal_year)+"/"+str(cal_month_id)+"/01"
        
        i = 1    
        for student in students_rec:
            mydict = {'sno':'SNO','student':'Student','father':'Father','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','other':'','total':'TOTAL'}
            mydict['student'] = student.name
            mydict['father'] = student.father_name
            mydict['sno'] = i
            print "student::",student.id
            j = 1
            ft_total = 0
            for ft in ft_ids:
                mydict['ft'+str(j)] = '-'
                if ft[1] == 'Monthly_Fee':
                    sql = """SELECT sum(smsfee_studentfee.paid_amount) FROM smsfee_studentfee
                             INNER JOIN smsfee_classes_fees
                             ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                             WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                             AND smsfee_studentfee.reconcile = True
                             AND smsfee_studentfee.paid_amount>0
                             AND smsfee_studentfee.student_id = """+str(student.id)+"""
                             AND smsfee_studentfee.acad_cal_id = """+str(cls_id)+"""
                             AND smsfee_studentfee.fee_month = """+str(self.datas['form']['month'][0])
                else:
                    sql = """SELECT sum(smsfee_studentfee.paid_amount) FROM smsfee_studentfee
                         INNER JOIN smsfee_classes_fees
                         ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                         WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                         AND smsfee_studentfee.reconcile = True
                         AND smsfee_studentfee.paid_amount>0
                         AND smsfee_studentfee.student_id = """+str(student.id)+"""
                         AND smsfee_studentfee.acad_cal_id = """+str(cls_id)+"""
                         AND smsfee_studentfee.due_month = '"""+str(self.datas['form']['month'][0])+"""'"""
                print sql
                self.cr.execute(sql)
                amount = self.cr.fetchone()[0]
                if amount is None:
                    amount = 0
                ft_total = int(ft_total) + int(amount)
                mydict['ft'+str(j)] = amount
                j = j + 1
            mydict['total'] = ft_total
            i = i + 1
            result.append(mydict)
        return result
    
#--------------------------------------------------------------------------------------------------------------------------------------------------------    

    def monthwise_defaulter_studentslist(self, data):                                                         
            result = []
            """Late fee amount is not shown. to show it, make another columns on right side of others and mention it in separate column"""
            this_form = self.datas['form']
            cls_id = this_form['class_id'][0]
            std_ids = self.pool.get('sms.student').search(self.cr, self.uid,[('current_class', '=', cls_id)])
            students_rec = self.pool.get('sms.student').browse(self.cr, self.uid,std_ids)
            
            mydict = {'sno':'SNO','student':'Student','father':'Father','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','others':'Others','total':'TOTAL'}
            sql_fs = """ SELECT DISTINCT smsfee_feetypes.id,smsfee_feetypes.subtype  FROM smsfee_feetypes
                         INNER JOIN smsfee_classes_fees
                         ON smsfee_feetypes.id = smsfee_classes_fees.fee_type_id
                         WHERE  smsfee_classes_fees.academic_cal_id = """+str(cls_id)+"""
                         AND smsfee_feetypes.subtype = 'Monthly_Fee'"""
            self.cr.execute(sql_fs)
            ft_ids = self.cr.fetchall()
            
            c = 1
            for idss in ft_ids:
                print "fee types:",idss
                ftname = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,idss[0]).name
                mydict['ft'+str(c)] = ftname
                c= c + 1
            result.append(mydict)
            ############################################################################################################################
            
            cal_month = self.pool.get('sms.session.months').browse(self.cr, self.uid,self.datas['form']['month'][0])
            cal_month_id = cal_month.session_month_id.id
            cal_year = cal_month.session_year
            month_end =str(cal_year)+"/"+str(self.pool.get('sms.session.months').get_month_end_date(self.cr, self.uid,cal_month,cal_year))
            month_start = str(cal_year)+"/"+str(cal_month_id)+"/01"
            
            i = 1    
            for student in students_rec:
                mydict = {'sno':'SNO','student':'Student','father':'Father','ft1':'','ft2':'','ft3':'','ft4':'','ft5':'','others':'','total':'TOTAL'}
                mydict['student'] = student.name
                mydict['father'] = student.father_name
                mydict['sno'] = i
                j = 1
                tuitionfee_total = 0
                paybles = ''
                for ft in ft_ids:
                    sql = """SELECT smsfee_studentfee.fee_amount,smsfee_studentfee.paid_amount,smsfee_studentfee.reconcile FROM smsfee_studentfee
                             INNER JOIN smsfee_classes_fees
                             ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                             WHERE smsfee_classes_fees.fee_type_id = """+str(ft[0])+"""
                             AND smsfee_studentfee.student_id = """+str(student.id)+"""
                             AND smsfee_studentfee.acad_cal_id = """+str(cls_id)+"""
                             AND smsfee_studentfee.fee_month = """+str(self.datas['form']['month'][0])
                    self.cr.execute(sql)
                    rec = self.cr.fetchone()   
                    if rec:
                        if rec[2]==False:
                           paybles = rec[0]
                           tuitionfee_total = int(tuitionfee_total) + int(paybles) 
                           
                        else:
                            paybles = 'Paid'
                    mydict['ft'+str(j)] = paybles
                    j = j + 1
                    
                others = 0
                sql2 = """SELECT sum(smsfee_studentfee.fee_amount) FROM smsfee_studentfee
                         INNER JOIN smsfee_classes_fees
                         ON smsfee_classes_fees.id = smsfee_studentfee.fee_type 
                         INNER JOIN smsfee_feetypes 
                         ON smsfee_feetypes.id = smsfee_classes_fees.fee_type_id  
                         WHERE  smsfee_studentfee.reconcile = False
                         AND smsfee_studentfee.paid_amount=0
                         AND smsfee_feetypes.subtype !='Monthly_Fee'
                         AND smsfee_studentfee.student_id = """+str(student.id)+"""
                         AND smsfee_studentfee.acad_cal_id = """+str(cls_id)
                   
                self.cr.execute(sql2)
                rec2 = self.cr.fetchone()
                print "rec2:",rec2
                if not rec2[0] ==None:
                    others = rec2[0]
                    mydict['others'] = others
                    print "other2:",others
                print "other3: ",others
                mydict['total'] = tuitionfee_total + others
                i = i + 1
                result.append(mydict)
            return result
#---------------------------------------------------------------------------------------------------------------------------------------------------

    def student_fee_receipts(self, data):                                                         
            result = []
            """student unpaid fee receipt"""
            this_form = self.datas['form']
            cls_id = this_form['class_id'][0]
            dated = this_form['today']
            class_rec = self.pool.get('sms.academiccalendar').browse(self.cr, self.uid,cls_id)
            std_ids = self.pool.get('sms.student').search(self.cr, self.uid,[('current_class', '=', cls_id)])
            students_rec = self.pool.get('sms.student').browse(self.cr, self.uid,std_ids)
            
#             mydict = {'sno':'SNO','student':'Student','father':'Father','class':'Class','month':'Month','fee_arr':''}
#             
#             sql_fs = """ SELECT DISTINCT smsfee_feetypes.id,smsfee_feetypes.subtype  FROM smsfee_feetypes
#                          INNER JOIN smsfee_classes_fees
#                          ON smsfee_feetypes.id = smsfee_classes_fees.fee_type_id
#                          WHERE  smsfee_classes_fees.academic_cal_id = """+str(cls_id)+"""
#                          AND smsfee_feetypes.subtype = 'Monthly_Fee'"""
#             self.cr.execute(sql_fs)
#             ft_ids = self.cr.fetchall()
#             
#             c = 1
#             for idss in ft_ids:
#                 ftname = self.pool.get('smsfee.feetypes').browse(self.cr, self.uid,idss[0]).name
#                 mydict['ft'+str(c)] = ftname
#                 c= c + 1
#             result.append(mydict)
            ############################################################################################################################
            
#             month = dated.split('-')
#             print "month:",month
#             month = month[1]
#             year = month[0]
#             day = '10'
#             due_date = day+"-"+month+"-"+year
            
            i = 1    
            for student in students_rec:
                mydict = {'student':'Student','feestrc':'','father':'Father','class':'Class','dated':dated,'duedate':'due_date','total':'total','fee_arr':''}
                fs = self.pool.get('sms.feestructure').browse(self.cr, self.uid,student.fee_type.id).name
                mydict['sno'] = i
                mydict['student'] = student.name
                mydict['feestrc'] = fs
                mydict['father'] = student.father_name
                mydict['class'] = class_rec.name
                mydict['dated'] = dated
                
                sql = """SELECT smsfee_studentfee.fee_amount, smsfee_studentfee.fee_type,
                         smsfee_studentfee.fee_month  FROM smsfee_studentfee
                         INNER JOIN smsfee_classes_fees
                         ON smsfee_classes_fees.id = smsfee_studentfee.fee_type  
                         WHERE smsfee_studentfee.student_id = """+str(student.id)+"""
                         AND smsfee_studentfee.reconcile = False
                         AND smsfee_studentfee.acad_cal_id = """+str(cls_id)
                self.cr.execute(sql)
                rec = self.cr.fetchall() 
                total = 0
                result2 = []
                if rec:
                    j = 1
                    for fees in rec:
                        print "fees: ", fees
                        total = total +fees[0]
                        fee_dic = {'sno':'','fee_name':'','amount':''} 
                        fee_dic['sno'] = j
                        if fees[0] ==0:
                            fee_dic['amount'] = "0"
                        else:
                            fee_dic['amount'] = fees[0]    
                        fee_name = self.pool.get('smsfee.classes.fees').browse(self.cr, self.uid,fees[1] ).name
                        if fees[2]:
                           fee_month =  self.pool.get('sms.session.months').browse(self.cr, self.uid,fees[2] ).name
                           fee_name = fee_name+"("+fee_month+")"
                        fee_dic['fee_name'] = fee_name
                        result2.append(fee_dic)
                        j = j + 1
                    
                    mydict['total'] = total
                    mydict['fee_arr'] = result2        
                    i = i + 1
                    print "result2: ", result2
                    result.append(mydict)
            return result
#------------------------------------------------------------------------------------------------------------------------------------------
    def daily_fee_report(self, data):                                                         
        result = []
        ####
        this_form = self.datas['form']
        cls_id = this_form['class_id']
        fee_manager = this_form['fee_manager']
        if cls_id:
            this_form['class_id'][0]
            cls_qry = """AND student_class_id= """+str(this_form['class_id'][0])
        else:
            cls_qry = """ """ 
        if fee_manager:
             fm_query = """AND fee_received_by = """+str(this_form['fee_manager'][0])  
        else:
             fm_query ="""""" 
        print "class ids:",cls_id
        
        ###
        
        
        sql_rb = """ SELECT total_paid_amount,student_class_id,student_id,fee_received_by,receipt_date,
                     name FROM smsfee_receiptbook                              
                     WHERE smsfee_receiptbook.receipt_date >= '"""+str(this_form['from_date'])+"""'
                     AND smsfee_receiptbook.receipt_date <= '"""+str(this_form['to_date'])+"""'
                     """+cls_qry+"""
                     """+fm_query+"""
                     AND smsfee_receiptbook.state='Paid'
                     AND smsfee_receiptbook.total_paid_amount>0 ORDER By receipt_date """
                             
        self.cr.execute(sql_rb)
        rb_ids = self.cr.fetchall()
        c = 1
        dict1 = {'total_amount':'','arr':''}
        total_amount = 0
        result2 = []
        for idss in rb_ids:
            mydict = {'sno':'SNO','paid_amount':'class_name','student_name':'fee_received_by','receipt_date':'','receipt_no':''}
            student_name = self.pool.get('sms.student').browse(self.cr, self.uid,idss[2]).name
            class_name = self.pool.get('sms.academiccalendar').browse(self.cr, self.uid,idss[1]).name
            user = self.pool.get('res.users').browse(self.cr, self.uid,idss[3]).name
            total_amount = total_amount + idss[0]
            dated = self.pool.get('sms.session').set_date_format(self.cr, self.uid,idss[4])
            mydict['sno'] = c
            mydict['receipt_date'] = dated
            mydict['paid_amount'] = idss[0]
            mydict['class_name'] = class_name
            mydict['student_name'] = student_name
            mydict['fee_received_by'] = user
#             mydict['receipt_no'] = idss[5]
            c= c + 1
            result2.append(mydict)
        dict1['arr'] = result2 
        dict1['total_amount'] = total_amount  
        result.append(dict1)
        return result
    
       
report_sxw.report_sxw('report.smsfee.annaul.allclasses.name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_annual_allclasses.rml',parser = smsfee_report_feereports, header='internal')
report_sxw.report_sxw('report.smsfee.annaul.singleclass.name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_annual_singleclass.rml',parser = smsfee_report_feereports, header='internal')
report_sxw.report_sxw('report.smsfee.monthlyfeecollection.allclasses.name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_monthly_feecollection_allclasses.rml',parser = smsfee_report_feereports, header='internal')
report_sxw.report_sxw('report.smsfee_students_paidfee_report_name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_students_paid_fee_report.rml',parser = smsfee_report_feereports, header='internal')
report_sxw.report_sxw('report.smsfee_monwisedefaulterlist_name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_monwisedefaulterlist_report.rml',parser = smsfee_report_feereports, header='internal')
report_sxw.report_sxw('report.smsfee_unpaidfee_receipt_name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_unpaid_receipts_report.rml',parser = smsfee_report_feereports, header='internal')
report_sxw.report_sxw('report.smsfee.dailyfee.report.name', 'smsfee.classfees.register', 'addons/smsfee/smsfee_dailyfee_report.rml',parser = smsfee_report_feereports, header='internal')

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

