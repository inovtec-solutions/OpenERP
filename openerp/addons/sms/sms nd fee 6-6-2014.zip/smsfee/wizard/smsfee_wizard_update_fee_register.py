from openerp.osv import fields, osv
import datetime

class update_fee_register(osv.osv_memory):

    def _get_thisclass(self, cr, uid, ids):
        clsobj = self.browse(cr, uid, ids['active_id'])
        cls_id =  clsobj.id
        return cls_id
    
        
    def _get_fee_month(self, cr, uid, ids):
        clsobj = self.browse(cr, uid, ids['active_id'])
        acad_cal = self.pool.get('sms.academiccalendar').browse(cr,uid,clsobj.id)
        month_id =  acad_cal.fee_update_till.id
        if month_id:
           return month_id
        else:
            return 0
    
    def _get_class_session(self, cr, uid, ids):
        clsobj = self.browse(cr, uid, ids['active_id'])
        acad_cal = self.pool.get('sms.academiccalendar').browse(cr,uid,clsobj.id)
        session_id =  acad_cal.session_id.id
        return session_id
        
    
    _name = "update.fee.register"
    _description = "Update monthy class register"
    _columns = {
              'action':fields.selection([('update_class_monthly_fee', 'Update Monthly Fees Register'),('add_fee_to_class', 'Add Fee To Class'),('add_fee_to_singlestudent','Add Fee to Student')], 'Action', required = True),      
              'session': fields.many2one('sms.session', 'Session', domain="[('state','!=','Previous')]",readonly = True,help="Select an academic session"),
              "name": fields.many2one('sms.academiccalendar', 'Class', domain="[('state','=','Active'),('fee_defined','=',1)]", readonly=True, help="Select A class to load its subjects."),
              'student_id':fields.many2one('sms.student', 'Student', domain="[('current_class','=',name)]"),
              'fee_type':fields.many2one('smsfee.feetypes', 'Fee', domain="[('subtype','=','Other')]"),
              'fee_amount':fields.float('Amount'),
              "updated_till": fields.many2one('sms.session.months', 'Upadted Till',readonly=True, help="Class Session."),
              'update_upto': fields.many2one('sms.session.months', 'Update Upto', domain="[('session_id','=',session)]" ,help="Fee Is update upto shown month."),
              'month_of_dues': fields.many2one('sms.session.months', 'Dues Month', domain="[('session_id','=',session)]" ,help="Fee Is update upto shown month."),
              'display_string': fields.char('Message',size =32,readonly = True),
               }
    _defaults = {
          'name':_get_thisclass,
          'session':_get_class_session,
          'updated_till':_get_fee_month,
          'display_string':'Update Class Fee Register till selected month. Please mention month.'
           }
    
    
    
    def update_feeregister(self, cr, uid, ids, data):
        result = []
        for f in self.browse(cr, uid, ids):
            action = f.action
            acad_cal =f.name.id 
            if action == 'update_class_monthly_fee':
                 
                update_upto = f.update_upto.id
                acad_cal_obj = self.pool.get('sms.academiccalendar').browse(cr,uid,acad_cal)
                session_id =  acad_cal_obj.session_id.id
               
                #months to be updated
                months_id = self.pool.get('sms.session.months').search(cr,uid,[('session_id','=',session_id)])
                #student of current semeste with their fee structure
                acad_cal_stds = self.pool.get('sms.academiccalendar.student').search(cr,uid,[('name','=',acad_cal),('state','=','Current')])
                cal_std_objs = self.pool.get('sms.academiccalendar.student').browse(cr,uid,acad_cal_stds)
                # Get fee types from smsfee with type monthly fee.
    #             fee_type_ids = 
                for month in months_id:
                    # check if month for given class is already updated
                    month_exists = self.pool.get('smsfee.classfees.register').search(cr,uid,[('month','=',month),('academic_cal_id','=',acad_cal)])
                    print "month idL",month
                    if not month_exists:
                        if month <= update_upto:
                            updated_fee_till = month
                            for cal_std_obj in cal_std_objs:
                                #print "cal_std_id",cal_std_id
                                #cal_std_obj = self.pool.get('sms.academiccalendar.student').browse(cr,uid,cal_std_id)
                                #print "std_id1",cal_std_obj.std_id
                                std_id = cal_std_obj.std_id.id
                                if not std_id:
                                    continue
                                std_obj = self.pool.get('sms.student').browse(cr,uid,std_id)
                                std_feestr = std_obj.fee_type.id
                                total_paybles = std_obj.total_paybles
                                # get monthly fees from classes fee with fee structure define with student,with subtype monthly fee
    #                             monthly_feeids = self.pool.get('smsfee.classes.fees').search(cr,uid,[('fee_structure_id','=',std_feestr),('academic_cal_id','=',acad_cal),('fee_type_subtype','=','Monthly_Fee')])
                                                               
                                ft_idss2 = self.pool.get('smsfee.feetypes').search(cr,uid,[('subtype','=','Monthly_Fee')])
                                ft_idss2 = tuple(ft_idss2)
                                ft_idss2 = str(ft_idss2).rstrip(',)')
                                ft_idss2 = ft_idss2+')'
                                print "feetype ids:",ft_idss2
                                sqlfee2 = """SELECT smsfee_classes_fees.id from smsfee_classes_fees
                                            INNER JOIN smsfee_feetypes
                                            on smsfee_feetypes.id = smsfee_classes_fees.fee_type_id WHERE
                                            academic_cal_id ="""+str(acad_cal)+""" AND fee_structure_id="""+str(std_feestr)+"""
                                            AND smsfee_feetypes.id IN"""+str(ft_idss2)+""""""
                                print "sql::",sqlfee2
                                cr.execute(sqlfee2)
                                monthly_feeids = cr.fetchall()
                                print "fee_ids",monthly_feeids
                                 
                                for feetype in monthly_feeids:
                                    print "fee type id::",feetype[0]
                                    cls_fee_obj = self.pool.get('smsfee.classes.fees').browse(cr,uid,feetype[0])
                                    print "clas fee:",cls_fee_obj.amount
                                    print "clas fee ids:",cls_fee_obj.id
                                    #check if student is already charged with fee then only uodate record otherwiase insert his fee    
                                    std_fee_ids = self.pool.get('smsfee.studentfee').search(cr,uid,[('acad_cal_std_id','=',cal_std_obj.id),('reconcile','=',False),('fee_type','=',feetype[0]),('fee_month','=',month)])
                                    if std_fee_ids:
                                        std_fee_obj =self.pool.get('smsfee.studentfee').write(cr, uid, std_fee_ids,{
                                                            'acad_cal_id':acad_cal,                                                       
                                                            'student_id':std_id,
                                                            'acad_cal_std_id':cal_std_obj.id,
                                                            'date_fee_charged':datetime.date.today(),
                                                            'fee_type':feetype[0],
                                                            'fee_month':month,
                                                            'due_month':month, 
                                                            'fee_amount':cls_fee_obj.amount,
                                                            'paid_amount':0,
                                                            'total_amount':cls_fee_obj.amount,                                                       
                                                            'net_total':cls_fee_obj.amount,
                                                            'reconcile':False
                                                           })
                                    else:
                                        std_fee_obj = self.pool.get('smsfee.studentfee').create(cr,uid,{
                                                            'acad_cal_id':acad_cal,                                                       
                                                            'student_id':std_id,
                                                            'acad_cal_std_id':cal_std_obj.id,
                                                            'fee_type':feetype[0],
                                                            'fee_month':month,
                                                            'due_month':month, 
                                                            'fee_amount':cls_fee_obj.amount,
                                                            'total_amount':cls_fee_obj.amount,                                                       
                                                            'net_total':cls_fee_obj.amount,
                                                            'reconcile':False
                                                            })
                                #pdate sms.student for total fee pables
                                std_paybles = self.pool.get('smsfee.studentfee').get_student_total_paybles(cr, uid, std_id,cal_std_obj.id)
                                update_paybles = self.pool.get('sms.student').write(cr, uid, std_id,{'total_paybles':std_paybles})
                            #update register object ofr this month
                            fee_register = self.pool.get('smsfee.classfees.register').create(cr,uid,{
                                                        'academic_cal_id':acad_cal,                                                       
                                                        'month':month, 
                                                            }) 
                            updated_till = self.pool.get('sms.academiccalendar').write(cr,uid,acad_cal,{'fee_update_till':updated_fee_till})
                    else:
                        print "this month is already updated ",month
            else:
                 #search selected fee in class
                 # Other(subtype = others) fees should be charged with normal fee structure for all students, no other fs is entertained
                 sqlfee = """SELECT smsfee_classes_fees.id from smsfee_classes_fees
                            WHERE academic_cal_id ="""+str(acad_cal)+""" AND fee_structure_id=1
                            AND smsfee_classes_fees.fee_type_id ="""+str(f.fee_type.id)+""""""
                 print "sql::",sqlfee
                 cr.execute(sqlfee)
                 class_fee_id = cr.fetchone()
                 print "fee_ids",class_fee_id
                 if class_fee_id:
                     #add fee to individual student
                     if action == 'add_fee_to_singlestudent':
                         acad_cal_stdid = self.pool.get('sms.academiccalendar.student').search(cr,uid,[('std_id','=',f.student_id.id),('name','=',acad_cal)])
                         if acad_cal_stdid:
                            std_fee_obj = self.pool.get('smsfee.studentfee').create(cr,uid,{
                                                                'acad_cal_id':acad_cal,                                                       
                                                                'student_id':f.student_id.id,
                                                                'acad_cal_std_id':acad_cal_stdid[0],
                                                                'fee_type':class_fee_id[0],
                                                                'fee_month':'',
                                                                'due_month':f.month_of_dues.id, 
                                                                'fee_amount':f.fee_amount,
                                                                'total_amount':'',                                                       
                                                                'net_total':'',
                                                                'reconcile':False
                                                                })
                     else:
                         #add Fee to the whole class
                         acad_cal_stdids = self.pool.get('sms.academiccalendar.student').search(cr,uid,[('state','=','Current'),('name','=',acad_cal)])
                         acad_cal_stdids_rec = self.pool.get('sms.academiccalendar.student').browse(cr,uid,acad_cal_stdids)
                         for idss in acad_cal_stdids_rec:
                             
                             std_fee_obj = self.pool.get('smsfee.studentfee').create(cr,uid,{
                                              'acad_cal_id':acad_cal,                                                       
                                              'student_id':idss.std_id.id,
                                              'acad_cal_std_id':idss.id,
                                              'fee_type':class_fee_id[0],
                                              'fee_month':'', 
                                              'due_month':f.month_of_dues.id, 
                                              'fee_amount':f.fee_amount,
                                              'total_amount':'',                                                       
                                              'net_total':'',
                                              'reconcile':False
                                              })
                     
                 else:
                     # Fee type ins given class is not found with fee strucutre Normal
                     feetype = self.pool.get('smsfee.feetypes').browse(cr,uid,f.fee_type.id).name    
                     acad_cal_name = self.pool.get('sms.academiccalendar').browse(cr,uid,acad_cal).name   
                     raise osv.except_osv(('Fee Not Found'),('Fee:'+str(feetype)+' not found for '+str(acad_cal_name))) 
                            
                          
        return result
update_fee_register()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: